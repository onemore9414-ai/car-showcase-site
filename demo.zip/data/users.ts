
import { User } from '../types';

export const USERS: User[] = [
  {
    id: "admin-1",
    name: "Admin User",
    email: "admin@brand.com",
    role: "admin",
    joinedDate: "2024-01-01T00:00:00.000Z",
    avatar: "https://ui-avatars.com/api/?name=Admin+User&background=000&color=fff"
  }
];
