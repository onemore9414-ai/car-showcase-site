
/**
 * DEPRECATED: Storage logic has been moved to database/storage.ts
 * This file remains empty to prevent import errors during transition, 
 * although controllers have been updated to use the new Database adapter.
 */
export {}; 
